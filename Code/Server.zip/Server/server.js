const bodyParser= require('body-parser')
const express = require('express');
const app = express();
const MongoClient = require('mongodb').MongoClient
var db
var fs = require('fs');
var multer = require('multer')

app.use(express.static(__dirname+'/public'));

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './public/images/')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
})

var upload = multer({ storage: storage })


app.use(bodyParser.urlencoded({extended: true}))
app.set('view engine', 'ejs')
 
MongoClient.connect('mongodb://127.0.0.1:27017/', (err, database) => {
    if (err) return console.log(err)
    db = database.db('parkingspot')
    app.listen(3000, () => {
    console.log('listening on 3000')
  })
})


//function removeDocuments(){
//  db.collection('spotdata', {}, function(err, spotdata) {
//      spotdata.remove({}, function(err, result) {
//          if (err) throw err;
//          return(console.log(result.result.n + " document(s) deleted"))
//      }) 
//  })  
//}

function saveToDB(data){ 
    spots=data.spots
    for ( var i in spots) {
	    var spotnumber = spots[i].spotnumber;
	    var status = spots[i].status;
	    console.log(spotnumber);
      console.log(status);
      db.collection('spotdata').update({'spotnumber':spotnumber}, {$set: {'spotnumber':spotnumber, 'status':status}},{ upsert: true })
    }
    return('saved to database')
}


app.get('/spot-data', (req, res) => {
    var data = JSON.parse(req.query.data)
    console.log(data)
    //console.log(removeDocuments())
    console.log(saveToDB(data))
    res.redirect('/')
  })

app.get('/', (req, res) => {
    db.collection('spotdata').find().toArray((err, result) => {
      if (err) return console.log(err)
      res.render('index.ejs', {spotdata: result})
    })
 })

 app.post('/uploadImage',upload.single('file'), function(req, res) {
  if(req.file) console.log(req.file)
  res.send("success")
  res.redirect('/showImage')
})

app.get('/showImage', function(req, res) {

  res.render('image.ejs', function(error, content) {
      if (error) {
          res.end();
      }
      else {
          res.end(content, 'utf-8');
      }
  });

});

