data = {
    'spots':[
        {
            'spotnumber':1,
            'status':'FULL'
         },
        {
            'spotnumber':2, 
            'status':'FULL'
        },
        {
            'spotnumber':3,
             'status':'EMPTY'
        }
        ]
    }
fetch("http://localhost:3000/makeRequest", {method: "POST", body: JSON.stringify(data)})
.then(res=>{
    console.log(res);
})
