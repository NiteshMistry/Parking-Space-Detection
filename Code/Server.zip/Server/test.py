# This code has dummy data in dictionary which is then converted to json and sent to the server. This code can be used to test client-server connection.


import json
import requests

data = {
    'spots':[
        {
            'spotnumber':1,
            'status':'FULL'
         },
        {
            'spotnumber':2, 
            'status':'FULL'
        },
        {
            'spotnumber':3,
             'status':'EMPTY'
        },
        {
            'spotnumber':4,
             'status':'EMPTY'
        }
        ]
    }

data_json = json.dumps(data)
headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
#r = requests.get('http://localhost:3000/spot-data?data='+data_json)
r = requests.get('http://2bd1aa55.ngrok.io/spot-data?data='+data_json)
print(r)

exit()